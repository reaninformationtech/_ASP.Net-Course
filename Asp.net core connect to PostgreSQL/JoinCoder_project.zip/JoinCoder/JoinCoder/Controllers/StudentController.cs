﻿using JoinCoder.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JoinCoder.Controllers
{
    public class StudentController : Controller
    {
        private readonly ApplicationContext _context;
        public StudentController(ApplicationContext context)
        {
            _context = context;
        }
        public IActionResult studentlist()
        {
            ViewBag.users = _context.students.ToList();
            return View();
        }
    }
}
